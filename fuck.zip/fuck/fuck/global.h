// --------------------include files--------------------
#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <float.h>
#include <fstream>
#include <iomanip>
#include <string.h>
#include <stdio.h>
#include <assert.h>
using namespace std;

// --------------------Global variables--------------------
#define E        exp(1)
#define PI        acos(-1)
#define INF        DBL_MAX
#define EPS        DBL_EPSILON        // the precision of the constraints
#define DELTA    DBL_EPSILON

#define max(a,b) (((a) > (b)) ? (a) : (b))
