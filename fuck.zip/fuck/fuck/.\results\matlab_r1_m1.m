clear;clc;
x = [-0.960617 -0.936221 -0.872533 -0.84737 -0.800927 -0.59593 -0.57921 -0.412642 0.0429562 ...
0.623517 1.37052 ]';
y = [2.01246 1.95601 1.89118 1.86448 1.80974 1.61148 1.59409 1.42594 0.970246 ...
0.382135 0.370396 ]';
figure(1)
hndl=plot(x,y,'o','markerfacecolor', 'b');
set(hndl,'LineWidth',2)
set(gcf,'Units','centimeters','Position',[10 10 12 9]);
xlabel('f1','FontSize',10)
ylabel('f2','FontSize',10)
