// Individual.cpp: implementation of the CIndividual class.
//
//////////////////////////////////////////////////////////////////////

#include "Individual.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

int CIndividual::num_of_equations	= 10;
int CIndividual::N_of_x				= 10;
int CIndividual::N_of_obj			= 2;
long int CIndividual::MAX_NFEs		= 50000;
//int CIndividual::index_of_func	= 1;

CIndividual::CIndividual()
{
	int i;
	for (i=0;i<MAX_N_of_x;i++)
	{
		xreal[i] = 10000.0;
	}
	for (i=0;i<MAX_N_of_obj;i++)
	{
		obj[i] = -1.0;
		box[i] = -1.0;
	}
	rank          = -1;
	crowd_dist    = INF;
	non_dominated = -1;

	for (i=0;i<MAX_N_of_obj;i++)
	{
		f_e_f[i] = -1.0;
	}
	sum_f_e_f = -1.0;

	used_in_ranking = 0;

	CR = 0.9;
	FF = 0.5;
}

CIndividual::~CIndividual()
{
}

CIndividual::CIndividual(const CIndividual &t)
{
	if(&t == this)
	{
		return;
	}
	
	int i;
	for (i=0;i<MAX_N_of_x;i++)
	{
		xreal[i] = t.xreal[i];
	}
	for (i=0;i<MAX_N_of_obj;i++)
	{
		obj[i] = t.obj[i];
		box[i] = t.box[i];
	}
	rank			= t.rank;
	crowd_dist		= t.crowd_dist;
	non_dominated	= t.non_dominated;

	for (i=0; i<MAX_N_of_obj; i++)
	{
		f_e_f[i] = t.f_e_f[i];
	}
	sum_f_e_f = t.sum_f_e_f;

	used_in_ranking = t.used_in_ranking;

	CR = t.CR;
	FF = t.FF;
}

CIndividual &CIndividual::operator =(const CIndividual &t)
{
	if(&t == this)
	{
		return *this;
	}

    int i;
	for (i=0;i<MAX_N_of_x;i++)
	{
		xreal[i] = t.xreal[i];
	}
	for (i=0;i<MAX_N_of_obj;i++)
	{
		obj[i] = t.obj[i];
		box[i] = t.box[i];
	}
	rank			= t.rank;
	crowd_dist		= t.crowd_dist;
	non_dominated	= t.non_dominated;

	for (i=0; i<MAX_N_of_obj; i++)
	{
		f_e_f[i] = t.f_e_f[i];
	}
	sum_f_e_f = t.sum_f_e_f;

	used_in_ranking = t.used_in_ranking;

	CR = t.CR;
	FF = t.FF;

	return *this;
}