// GenerateMatlab.h: interface for the CGenerateMatlab class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GENERATEMATLAB_H__8E2AAC31_D6EB_4526_B39F_FBCFF96430F1__INCLUDED_)
#define AFX_GENERATEMATLAB_H__8E2AAC31_D6EB_4526_B39F_FBCFF96430F1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "../global.h"

class CGenerateMatlab  
{
public:
	CGenerateMatlab();
	virtual ~CGenerateMatlab();

public:
	void GenerateMatlabFile2(char *f_matlab);		// ����2Ŀ�꺯����Matlab�ļ�,���ڻ�ͼ
	void GenerateMatlabFile3(char *f_matlab);		// ����3Ŀ�꺯����Matlab�ļ�,���ڻ�ͼ
};

#endif // !defined(AFX_GENERATEMATLAB_H__8E2AAC31_D6EB_4526_B39F_FBCFF96430F1__INCLUDED_)
