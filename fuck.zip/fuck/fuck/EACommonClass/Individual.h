// Individual.h: interface for the CIndividual class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INDIVIDUAL_H__E94D9569_963D_4441_ADD9_28E405C2ADEB__INCLUDED_)
#define AFX_INDIVIDUAL_H__E94D9569_963D_4441_ADD9_28E405C2ADEB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "../global.h"

#define batch_execution			0		// 1: for batch execution; 0: original execution (mannual)


#define population_size			200		// population size

#define MAX_N_of_x				50		// maximal number of decision variables
#define MAX_N_of_obj			100		// maximal number of objective functions
#define MAX_ARCHIVE_SIZE		2000	// maximum size possible (the upper bound) of the archive


class CIndividual  
{
public:
	CIndividual();
	virtual ~CIndividual();

public:
	static int num_of_equations;
	static int N_of_x;
	static int N_of_obj;
	static long int MAX_NFEs;

public:
	CIndividual(const CIndividual &);							
	CIndividual &operator=(const CIndividual &);

public:
	double xreal[MAX_N_of_x];		// real-coded decision variable
	double obj[MAX_N_of_obj];		// the objective functions
	double box[MAX_N_of_obj];		// box vectors for the individual
	int    rank;					// the rank value of the individual
	double crowd_dist;				// crowding distance of the individual
	int    non_dominated;			// flag of non-dominated solution (0: dominated; 1: non-dominated)

	double f_e_f[MAX_N_of_obj];		// only for the NES problem
	double sum_f_e_f;				// only for the NES problem

	int	   used_in_ranking;

	double CR;
	double FF;

};

#endif // !defined(AFX_INDIVIDUAL_H__E94D9569_963D_4441_ADD9_28E405C2ADEB__INCLUDED_)
