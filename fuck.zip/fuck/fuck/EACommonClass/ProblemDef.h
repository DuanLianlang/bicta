// ProblemDef.h: interface for the CProblemDef class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROBLEMDEF_H__A21DF1C1_4C96_4FC1_B696_45FFF280153B__INCLUDED_)
#define AFX_PROBLEMDEF_H__A21DF1C1_4C96_4FC1_B696_45FFF280153B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "../global.h"

#include "Individual.h"

class CProblemDef  
{
public:
	CProblemDef();
	virtual ~CProblemDef();

public:
	double	e_f[100];
	void	evaluate_problem(double *xreal, double *f_e_f, double &sum_f_e_f, int func_flag);

	/************************************************************************/
	/* for the NES problems                                                 */
	/************************************************************************/
public:
	// Problems got from: S. Wu, Y. Wang, et al, TEC 2014
	void	test_NES_01(double *xreal, double *f_e_f);
	void	test_NES_02(double *xreal, double *f_e_f);
	void	test_NES_03(double *xreal, double *f_e_f);
	void	test_NES_04(double *xreal, double *f_e_f);
	void	test_NES_05(double *xreal, double *f_e_f);
	void	test_NES_06(double *xreal, double *f_e_f);
	void	test_NES_07(double *xreal, double *f_e_f);

	void	test_NES_08(double *x, double *f_e_f);		//				? solutions

	// Problems obtained from: TSMC-A2008 A New Approach for Solving Nonlinear Equations Systems	
	void	test_NES_09(double *x, double *f_e_f);		//				13 solutions
	void	test_NES_10(double *x, double *f_e_f);		//				1 solution
	void	test_NES_11(double *x, double *f_e_f);		//				1 solution
	// 1990 Chemical equilibrium systems as numerical test problems (4 solutions in [-1, 1]
	// 1995 Finding all solutions of nonlinearly constrained systems of equations (1 solution in [0.001, 100])
	// 2011 A new filled function method for an unconstrained nonlinear equation (F12, known solutions)
	void	test_NES_12(double *x, double *f_e_f);		//				1 solution (0.003431, 31.325636, 0.068352, 0.859530, 0.036963)  
	void	test_NES_13(double *x, double *f_e_f);
	void	test_NES_14(double *x, double *f_e_f);		//				10 solutions (at least)
	
	void	test_NES_15(double *x, double *f_e_f);		//				8 solutions

	// Problems obtained from: 2012 Solving nonlinear equations systems with a new approach based on invasive weed optimization algorithm and clustering
	void	test_NES_16(double *x, double *f_e_f);		//				3 solutions
	void	test_NES_17(double *x, double *f_e_f);		//				1 solution  (3,2,1,0)
	void	test_NES_18(double *x, double *f_e_f);
	void	test_NES_19(double *x, double *f_e_f);

	// Problems obtained from: 2014 Chaotic quantum behaved particle swarm optimization algorithm for solving nonlinear system of equations
	void	test_NES_20(double *x, double *f_e_f);		//				3 solutions
	void	test_NES_21(double *x, double *f_e_f);		//				1 solution

	// Problems obtained from: 2013 Solving nonlinear equations system via an efficient genetic algorithm with symmetric and harmonious individuals
	void	test_NES_22(double *x, double *f_e_f);		//				4 solutions (�ѸĶ�)
	void	test_NES_23(double *x, double *f_e_f);		//				2 solutions
	void	test_NES_24(double *x, double *f_e_f);		//				2 solutions (�ѸĶ�)

	// Problems obtained from: 2013 Imperialist competitive algorithm for solving systems of nonlinear equations
	void	test_NES_25(double *x, double *f_e_f);		// case 3		10 solutions (�ѸĶ�)

	// Problems obtained from: 2011 Particle swarm algorithm for solving systems of nonlinear equations
	void	test_NES_26(double *x, double *f_e_f);		// case 5		2 solutions

	// Problems obtained from: 2011 Finding all solutions of nonlinear systems using a hybrid metaheuristic with Fuzzy Clustering Means
	void	test_NES_27(double *x, double *f_e_f);		// case 2		12 solutions
	// 2011 A new filled function method for an unconstrained nonlinear equation (F28, known solutions)
	void	test_NES_28(double *x, double *f_e_f);		// case 3		9 solutions
	// 2011 A new filled function method for an unconstrained nonlinear equation (F29, known solutions)
	void	test_NES_29(double *x, double *f_e_f);		// case 4		2 solutions
	void	test_NES_30(double *x, double *f_e_f);		// case 5		13 solutions
	// 2011 A new filled function method for an unconstrained nonlinear equation (F31, known solutions)
	void	test_NES_31(double *x, double *f_e_f);		// case 6		16 solutions
	void	test_NES_32(double *x, double *f_e_f);		// case 8		2 solutions
	void	test_NES_33(double *x, double *f_e_f);		// case 9		8 solutions

	// Problems obtained from: 1987 Some tests of generalized bisection
	void	test_NES_34(double *x, double *f_e_f);		// case 1		6 solutions (�Ѿ��Լ��Ķ�)
	void	test_NES_35(double *x, double *f_e_f);		// case 4		2 solutions
	void	test_NES_36(double *x, double *f_e_f);		// case 10		1 solution (too easy)
	void	test_NES_37(double *x, double *f_e_f);		// case 14		2 solutions

	// Problems obtained from: 2013 On efficient weighted-Newton methods for solving systems of nonlinear equations
	void	test_NES_38(double *x, double *f_e_f);		// case 3	
	
	// Problems obtained from: 2003 Some Nonlinear Test Problems
	void	test_NES_39(double *x, double *f_e_f);		// simple-problem		4 solutions	
	void	test_NES_40(double *x, double *f_e_f);		// expsin problem		6 solutions		

	// Problems obtained from: 2011 Particle swarm algorithm for solving systems of nonlinear equations
	void	test_NES_41(double *x, double *f_e_f);		// case 2		1 solutions

	// Problems obtained from: 2010 Finding more than one root of nonlinear equations via a polarization technique - An application to double retrograde vaporization
	// 1999 Computer algebra methods for studying and computing molecular conformations (known solutions herein)
	void	test_NES_42(double *x, double *f_e_f);		// case 3		16 solutions

	// Problems obtained from: 1995 A combined method for enclosing all solutions of nonlinear systems of polynomial equations
	void	test_NES_43(double *x, double *f_e_f);		// case 5		8 solutions

	// Problems obtained from: 2014 An efficient hybrid method for solving systems of nonlinear equations
	void	test_NES_44(double *x, double *f_e_f);		// case 1		3 solutions
	void	test_NES_45(double *x, double *f_e_f);		// case 2		2 solutions

	// Problems obtained from: 2012 Solving nonlinear equations systems with a new approach based on invasive weed optimization algorithm and clustering
	void	test_NES_46(double *x, double *f_e_f);		// case 16		1 solutions

	// 2009 Conjugate direction particle swarm optimization solving systems of nonlinear equations
	void	test_NES_50(double *x, double *f_e_f);		// case 2		1 solution

	// 2011 Particle swarm algorithm for solving systems of nonlinear equations
	void	test_NES_51(double *x, double *f_e_f);		// case 7		2 solutions

	// 1990 Solving nonlinear equation systems via global partition and search - Some experimental results
	void	test_NES_52(double *x, double *f_e_f);		// case 3		1 solution

	// 1987 Some tests of generalized bisection
	void	test_NES_53(double *x, double *f_e_f);		// case 1		3 solutions

	// 2003 Some Nonlinear Test Problems
	void	test_NES_54(double *x, double *f_e_f);		// case 3		3 solutions

	// 2011 Frozen divided difference scheme for solving systems of nonlinear equations
	void	test_NES_55(double *x, double *f_e_f);		// case 2		5 solutions (modified)

	// 2009 An effective iterative method for computing real and complex roots of systems of nonlinear equations
	void	test_NES_56(double *x, double *f_e_f);		// case 1		4 solutions (minorly modified)

	// 2009 Some iterative methods for solving a system of nonlinear equations
	void	test_NES_57(double *x, double *f_e_f);		// case 1

	
	// problems with very large optimal solution	
	void	test_NES_81(double *x, double *f_e_f);		// XY model (APBC) 3x3
	
};

#endif // !defined(AFX_PROBLEMDEF_H__A21DF1C1_4C96_4FC1_B696_45FFF280153B__INCLUDED_)
