// Rand.h: interface for the CRand class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RAND_H__89B16F5C_AEF2_4153_886A_D08F14B63C3A__INCLUDED_)
#define AFX_RAND_H__89B16F5C_AEF2_4153_886A_D08F14B63C3A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "../global.h"

class CRand  
{
public:
	CRand();
	virtual ~CRand();

public:
	// Variable declarations for the random number generator
	static double oldrand[55];
	static int jrand;

public:
	// Function declarations for the random number generator
	void   randomize(double seed);
	void   warmup_random (double seed);
	void   advance_random (void);
	double randomperc(void);
	int    rndint (int low, int high);			// integer value 0~n-1
	double rndreal (double low, double high);	// real value
	double normal();							// Gaussian random number generator

	double gaussian(double median, double stdv);	// Gaussian random number
	double log_normal(double median, double stdv);	// Log-normal random number
	double cauchy(double median, double factor);	// Cauchy random number
	double levy(int freedom);						// Levy random number
	
	int    flip(double);
};

#endif // !defined(AFX_RAND_H__89B16F5C_AEF2_4153_886A_D08F14B63C3A__INCLUDED_)
